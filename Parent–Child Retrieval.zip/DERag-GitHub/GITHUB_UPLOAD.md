# Uploading this folder to GitHub

## Recommended: Git CLI

```powershell
cd DERag-GitHub

git init
git add .
git commit -m "Initial DERag project: legal RAG, chunking benchmark, P800 extension"
git branch -M main
git remote add origin https://github.com/<your-account>/<your-repo>.git
git push -u origin main
```

If the remote already has a README/commit:

```powershell
git pull origin main --allow-unrelated-histories
# resolve conflicts, then
git push origin main
```

## Alternative: GitHub web upload

GitHub's web uploader does not unpack a `.zip` automatically. Extract `DERag-GitHub.zip` first, then drag the **contents** of the `DERag-GitHub` folder into the repository root. The repository should show `README.md`, `app/`, `data/`, `exports/`, etc. at the top level.

Git CLI is preferable because this package has 400+ files.

## Size and large files

- Package size is about **27 MB**; the largest file is about **4.6 MB**.
- No file exceeds GitHub's 100 MB per-file limit, so Git LFS is not required.
- `artifacts/` (the ~306 MB full stage-evidence tree), `models/`, `.venv`, Chroma indexes and SQLite databases are intentionally excluded. They are covered by `.gitignore`.

## Before pushing

```powershell
# never commit a real key
Test-Path .env          # should be False

# optional: verify the P800 tests
& '.\.venv\Scripts\python.exe' -m pytest tests/test_parent_child.py -q
```

If you need the model or indexes on another machine, follow `README.md` Quick start; they are rebuilt locally, not stored in Git.
