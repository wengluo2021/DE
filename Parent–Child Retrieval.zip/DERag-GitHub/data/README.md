# Frozen data

This directory contains the frozen inputs used by the formal experiment. Do not edit the raw/processed files or the gold set in place: their SHA-256 values are recorded in the manifests and configuration.

## Versions

- `corpus_version`: `794e3d1956fc324659da149d5bfb0e083d257845895057b631d4578ec5b29795`
- `gold_version`: `9ecc1d148c00dacc354a401bdeae7dc019de871919d9ad673a53a9e491e9f07d`

## Layout

| Path | Contents |
|---|---|
| `sources.json` | Five EUR-Lex sources, versions, dates, snapshot paths and SHA-256 |
| `corpus_manifest.json` | Project-level freeze manifest |
| `raw/` | A's original HTML snapshots |
| `processed/` | A's accepted cleaned text and article/chapter structure |
| `formal_corpus/` | B's formal package: manifest, raw and processed files |
| `eval/gold.jsonl` | 30 frozen questions (24 answerable + 6 refusal) |
| `eval/manifest.json` | Gold version and coverage |
| `sample_corpus/`, `eval/sample.jsonl` | Integration sample, not the formal experiment |

All five documents are the original Official Journal versions, not later consolidated amendments. See `data/formal_corpus/manifest.json` for the per-file hashes and `docs/provenance/` for the review records.
