# Full stage artifacts (not uploaded)

The original working tree contains an `artifacts/` directory of about **306 MB**. It holds repeated per-round evaluation snapshots, per-case human-review packets, Linux/Windows test XML, Docker/restore logs, and intermediate restore exports.

Those files are deliberately **not** included in this GitHub-ready package:

- they are mostly generated evidence, not source;
- many are multi-megabyte repeated copies of the same 120-record evaluation;
- GitHub is not a good host for hundreds of MB of stage logs.

What is preserved instead:

- `exports/20261120-232137-eval-ca61c0c0/` — the latest scored evaluation, summary, CSV, paired comparison, review provenance, and results overview;
- `docs/` — design notes, stage handoffs, worklogs, and the C report;
- `docs/provenance/` — provenance and review records.

If a reviewer needs a specific stage artifact, regenerate it with the documented tests or restore it from the team's local delivery archive. The source and frozen inputs in this repository are sufficient to rebuild the indexes and run the experiment again.
