# Saved evaluation export (GitHub subset)

This directory is a GitHub-friendly subset of the export for the latest scored run:

```text
run_id: eval-ca61c0c0f4bc40339a321e93d80d0e45
```

The full original export also contains a SQLite backup and a presentation zip; both are omitted here because they are binary/large. The JSON and CSV are the authoritative saved results.

## Included files

| File | What it is |
|---|---|
| `summary.json` | Four-condition aggregate metrics |
| `evaluation.json` | 120 per-question records: retrieval, answer, citations, scores, review |
| `evaluation.csv` | Same records in flat CSV form |
| `paired-comparison.json` | Same-question results side by side across conditions |
| `b-analysis.json` | Chunking/retrieval cross-analysis |
| `results-overview.html` | Offline, filterable results page |
| `review-provenance.json` | Scoring source/reason/history for the 120 records |
| `runtime-config.json` | Public runtime configuration; no API key |
| `export-manifest.json`, `index-manifest.json`, `export-validation.json` | Export/index metadata and validation |
| `verification/` | English API tests and main test-suite records |
| `README.txt` | Original export notes |

## Scoring caveat

The 120 scores are mixed-source: **21 items were human-confirmed and 99 were scored with authorized AI assistance**. This is not an all-human independent gold standard. See `review-provenance.json` and `docs/C部分报告草稿.md`.

## Checksums

`SHA256SUMS.txt` in this run directory covers the files included in this subset. It is regenerated for this package and is not the original full-export checksum list.
