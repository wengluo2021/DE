"""DERag application package."""
