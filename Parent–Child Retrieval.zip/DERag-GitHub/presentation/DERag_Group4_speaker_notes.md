# DERag — 15-minute speaker script

**Total:** 15:00 · **Speaking:** ~13:00 · **Q&A buffer:** ~2:00

| Speaker | Section | Time |
|---|---|---|
| A | Opening + Data & Evaluation | 0:00–3:25 |
| B | Chunking & Retrieval | 3:25–6:25 |
| C | Trustworthy Answers | 6:25–9:20 |
| D | Parent–Child Retrieval | 9:20–12:00 |
| A | Conclusion | 12:00–12:45 |
| All | Q&A | 12:45–15:00 |

> Notes are also embedded in the PPTX speaker-notes pane.

## Slide 1 — Title — From Legal Text to Trusted Answers

[0:00–0:20 | A]
Good morning. We are Group 4. Our project asks a simple question: can a RAG system answer legal questions and show exactly which sentence supports each claim?
We did not train a model. We built a data pipeline, a chunking benchmark, a citation-checked answer layer, and one extension.
I'm A; I'll start with the data. B will cover chunking, C the answer pipeline, and D our extension. The whole talk is about 13 minutes, then we'll take questions.

## Slide 2 — Agenda — Four questions, one system

[0:20–0:50 | A]
We organized the talk around four questions, one per speaker.
First, what makes a legal answer trustworthy? That is data and evaluation.
Second, does chunking change what we retrieve? That is B's four-condition benchmark.
Third, can every claim be traced to a citation? That is C's answer pipeline.
Fourth, can finer retrieval fix the cases chunking still misses? That is D's parent-child extension.
Each section is about three minutes. The thread is: freeze the evidence, cut it carefully, check every claim, then diagnose what is left.

## Slide 3 — Section 01 — Data & Evaluation

[0:50–0:55 | A]
Let's start with the data layer: what we froze, and why the evaluation is strict.

## Slide 4 — A1 — The problem: legal answers need evidence

[0:55–1:55 | A]
A's job starts with a domain where answers are checkable: EU consumer law. We use five EUR-Lex directives — consumer rights, digital content, sale of goods, unfair commercial practices, and unfair terms — 121 main articles, 391,777 characters.
Three reasons this is a data problem. First, an LLM can sound confident while inventing a rule; legal answers need exact textual support. Second, law is structured: articles, paragraphs, exceptions. If a chunk cuts a clause, the answer can reverse. Third, evaluation must be auditable: a frozen question set and character-level evidence spans, not a vibe check.
The table shows the five directives and their main article counts. All five are original Official Journal versions, not later consolidated amendments. That scope is deliberate — we are not claiming to cover all EU law.

## Slide 5 — A2 — From official HTML to a frozen evidence map

[1:55–2:45 | A]
A's pipeline is deliberately boring: snapshot, hash, clean, map, freeze. We start from the official EUR-Lex pages, save the raw HTML, and record a SHA-256 for each file. Then we clean to UTF-8 with LF line endings and no BOM, and build a structure map: chapters, sections, and article intervals.
The code strip is a real example: Article 18 of the consumer-rights directive occupies characters 81,983 to 82,251. Every evidence span is a literal slice of that frozen text.
The quality gates are strict: a hash mismatch refuses to load; articles must be ordered, disjoint, and inside the text; the evidence slice must equal the frozen text; and we check five documents, 121 articles, 30 questions.
If the web page changes, the version changes; old runs still point to the old text. That is what makes citations reproducible.

## Slide 6 — A3 — The gold set: 30 questions, 42 evidence spans

[2:45–3:25 | A]
The gold set is the yardstick. 24 answerable questions, 6 should-refuse questions. 13 are single-article, 11 are multi-evidence, and 6 are unanswerable. Each answerable case has a reference answer, key facts, and one to three evidence spans with document and article IDs and exact character intervals.
Across the 24 answerable cases there are 42 evidence spans, from 68 to 393 characters, median 269.
The hit contract is strict: the union of retrieved intervals in the same document must fully cover the evidence span. Finding the same article is not enough. That strictness is deliberate; it is what makes the chunk-boundary question meaningful.
Only “correct” counts as correct; partial and wrong are reported separately. I'll hand over to B.

## Slide 7 — Section 02 — Chunking & Retrieval

[3:25–3:30 | B]
Now the core comparison: four ways to cut the same legal text.

## Slide 8 — B1 — Four conditions, one controlled comparison

[3:30–4:30 | B]
B's design is a 2×2. Two chunking methods — fixed window and article-structure — crossed with two character limits, 400 and 800. That gives four conditions: F400, S400, F800, S800. The chunk counts are 982, 1,415, 493, and 625; 3,515 chunks in total.
Everything else is held constant: the same five frozen directives, the same cleaned text, BGE-M3 with a pinned revision and 1024 dimensions, Chroma with cosine and the same HNSW settings, Top-5 retrieval, no overlap, and the same 30 questions. The only difference is how the text is cut.
One precision point: 400 and 800 are Python characters, not tokens. A token is a different unit; we did not mix them.
The main comparisons are F400 vs S400 and F800 vs S800; the secondary comparison is 400 vs 800.

## Slide 9 — B2 — What the chunkers actually do

[4:30–5:25 | B]
Fixed window is a ruler. Starting at character zero, cut every 400 or 800 characters. It can split a sentence, a condition, or an article. In the picture, the cut falls inside the delivery obligation; the exception may sit in the next chunk. That is boundary truncation.
Article-structure uses A's offsets. Within a chapter, it packs complete articles until the limit. If one article is too long, it splits at sentence boundaries; only if a single sentence still exceeds the limit does it hard-cut. The goal is to keep the legal unit together when it fits.
We also report the failures: S400 had 113 long-sentence fallbacks, S800 had zero, and the shortest S400 chunk was one character. So structure helps, but it is not magic.
All conditions cover the text exactly once, with no overlap and no stripping.

## Slide 10 — B3 — Result: S800 leads retrieval

[5:25–6:25 | B]
This is the headline for B. The chart shows Top-5 retrieval coverage. Orange is “any” — at least one evidence span fully covered. Red is “all” — every evidence span covered. S800 is best on both: 21 out of 24 any, 13 out of 24 all.
The table adds chunk counts and median context characters. Two patterns. Structure beats fixed at both sizes: plus two cases at 400, plus three at 800. Size helps even more: fixed goes from 4 to 10, structure from 6 to 13.
But 13 out of 24 is not solved; 11 answerable questions still lack full evidence coverage. One caveat: this is one frozen run, not a statistical proof; and context budgets are not exactly equal. That is why we report the per-question results, not just the average. C will show what those misses do to the final answers.

## Slide 11 — Section 03 — Trustworthy Answers

[6:25–6:30 | C]
Next: how the system turns retrieved text into answers that can be checked.

## Slide 12 — C1 — The answer pipeline

[6:30–7:25 | C]
C's key design choice: the model never writes the final free-text answer. The pipeline is question, Top-5 evidence, an evidence-only prompt, structured JSON claims, and backend validation. Each claim has text and citation numbers.
The backend checks four things: every citation number exists in this round; every claim has at least one citation; the evidence slice equals the frozen source; and the evidence snapshot is saved with the answer.
A failed check is an error or a retry, not a silent fallback. The model cannot return a second, unchecked answer, and citations are backend-managed, not parsed from prose. Retrieved but unused evidence is also retained in the snapshot, so the model cannot hide a missing hit.

## Slide 13 — C2 — A system, not a demo

[7:25–8:15 | C]
This is the system around that pipeline. Four pages: Chat, Documents, Chunk compare, and Evaluation. One FastAPI backend, background tasks, and persistence. Under it, SQLite for sessions, evidence snapshots, and scores; Chroma for the four indexes; and the frozen corpus plus gold set.
The engineering evidence matters: 120 scored records, 401 Windows tests, 400 Linux tests plus one Windows-only skip, and a restart/restore check that produced byte-identical JSON and CSV.
The health check separates liveness from data, index, and model readiness. If formal data is missing, the API returns 409 instead of silently showing a demo. One worker, one database, one active experiment configuration.

## Slide 14 — C3 — Results and failure analysis

[8:15–9:20 | C]
The results table is the full system. S800 is the strongest condition: 14 out of 24 complete answers, 7 partial, 3 wrong, and 50 out of 50 claims supported. But look at the other side: across all four conditions, 20 answerable questions were incorrectly refused. All 24 refusal records were correctly refused, but that does not offset the mis-refusals.
Three failure modes. First, boundary truncation: in Q17, fixed windows stop at “materially distorts”, so the model never sees the full general test. Second, wrong completion: in Q8, the citation ends at “nature of the”; the model writes “contract” instead of “lack of conformity”. Third, evidence found but answer incomplete: in Q2, Hit@5-all is true, but the answer omits the refund-deferral condition.
The key line is: S800 has 50/50 citation support, but only 14/24 complete answers. Citation accuracy is not answer completeness. Scoring is 21 items human-confirmed plus 99 authorized AI-assisted; we do not call it an all-human gold standard. D will show what we can do about the remaining ranking gap.

## Slide 15 — Section 04 — Parent–Child Retrieval

[9:20–9:25 | D]
Finally, the extension: one more retrieval strategy, built on the same frozen parents.

## Slide 16 — D1 — Not all misses are chunking failures

[9:25–10:15 | D]
D's starting point is a diagnostic, not a new chunk size. S800 has 625 parents. For 20 of the 24 answerable questions, all evidence fits inside some S800 parent — so the evidence is not missing from the index. But only 13 of those 24 are retrieved in the Top-5.
The bar shows the 24 answerable questions. 13 are covered. 7 are ranking failures: the right parent exists, it just isn't ranked. 4 are boundary or mixed cases; one is split across S800 boundaries, three are mixed.
So the question is: if the parent is already there, can a smaller child find it better? The next experiment should change retrieval granularity, not add another arbitrary chunk size.

## Slide 17 — D2 — P800: child finds, parent answers

[10:15–11:10 | D]
P800 reuses the S800 parent. We split each parent into 250-character sentence-aligned children. We embed only the children: 2,099 of them, from 2,343 spans. At query time we retrieve the Top-50 children, group them by parent, score a parent by its best child, and return the Top-5 parents. The LLM still sees the full 800-character parent.
That is the small-to-big idea: small for matching, big for reading. The parent stays the citation and evidence unit; the matched child is recorded for highlight.
Because the parent is identical to S800, this is a clean ablation: the evidence unit is the same, only the retrieval unit changes. Hit@5 and context length are directly comparable. The cost is one extra child index, not a rebuild of the four official indexes.

## Slide 18 — D3 — What we measure, and what is already done

[11:10–12:00 | D]
D's contribution is a controlled extension, not a claim. The experiment is retrieval-only first: Hit@1 and Hit@5, candidate coverage, context characters, and latency, paired against the saved S800 results on the same 24 questions. We only spend 30 generation calls if retrieval improves.
Already delivered: the parent-child split and aggregation module, a build script with a dry-run and a Chroma build, a paired evaluation script, and 9 out of 9 unit tests. On the real corpus we verified 625 parents, 2,343 children, and 2,099 indexed children. The real BGE-M3 and Chroma run is the next step.
We do not claim a P800 win yet. The headroom is clear: converting three of the seven ranking-gap cases would move Hit@5-all from 13 to 16 out of 24. That is headroom, not a result. A negative result would still be useful: it would say context completeness beats finer matching on this corpus.
If the real P800 run is finished before the talk, replace the “next” status with the actual hit and context numbers; do not present the headroom as a result.

## Slide 19 — Conclusion — One system, four contributions

[12:00–12:45 | A]
To close: A made the data auditable — five directives, 121 articles, 30 questions, 42 evidence spans. B showed that chunking matters: four conditions, 3,515 chunks, and S800 best at 13 out of 24 Hit@5-all and 14 out of 24 complete. C made every claim checkable: 120 records, 401 tests, 50 out of 50 citation support at S800, but still 20 mis-refusals. D diagnosed seven ranking-gap cases and built the P800 extension, with 2,099 children indexed and 9 out of 9 tests.
The takeaway is one sentence: chunking changes what the model can answer; citations make it auditable; retrieval granularity is the next lever. With more time we would run P800 end-to-end, compare at equal token budget, try hybrid retrieval, and add independent human scoring. Thank you.

## Slide 20 — Thank you / Q&A

[12:45–13:00 | All]
Thank you. We are happy to take questions. The backup details are in the speaker notes and the project report.
