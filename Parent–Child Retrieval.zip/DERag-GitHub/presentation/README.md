# 15-minute project presentation

| File | Purpose |
|---|---|
| `DERag_Group4_15min.pptx` | Editable 20-slide deck, speaker notes embedded |
| `DERag_Group4_15min.pdf` | PDF backup for the presentation room |
| `DERag_Group4_speaker_notes.md` | Printable speaker script with timing |

## Timing

| Speaker | Section | Time |
|---|---|---|
| A | Opening + Data & Evaluation | 0:00–3:25 |
| B | Chunking & Retrieval | 3:25–6:25 |
| C | Trustworthy Answers | 6:25–9:20 |
| D | Parent–Child Retrieval | 9:20–12:00 |
| A | Conclusion | 12:00–12:45 |
| All | Q&A buffer | 12:45–15:00 |

The deck follows the CityU template's crimson/orange visual language. All tables and charts are native editable PowerPoint objects.

## Updating the P800 slide

The P800 real BGE-M3/Chroma run was not completed when this package was assembled. Slide 18 therefore says `implementation complete / real run next / claim none yet`. If the run is completed before the presentation, update the status and numbers on slides 18–19; do not present the 7-case headroom as a measured result.
