# DERag: A Verifiable Legal RAG System

DERag is a course project for **CS5481 Data Engineering**. It builds a retrieval-augmented question-answering system over **five EU consumer-rights directives**, and requires every answer to be grounded in retrieved legal text with traceable citations.

The repository contains the full source, frozen corpus and gold set, the four-condition chunking experiment, the citation-checked answer/evaluation platform, a parent–child retrieval extension, saved results, and the final presentation.

## At a glance

| Item | Value |
|---|---:|
| EU directives | 5 |
| Main articles | 121 |
| Frozen characters | 391,777 |
| Evaluation questions | 30 (24 answerable + 6 should-refuse) |
| Evidence spans | 42 |
| Chunking conditions | 4 (F400 / S400 / F800 / S800) |
| Logical chunks | 3,515 |
| Scored records | 120 (4 × 30) |
| Automated tests | 401 Windows / 400 Linux + 1 Windows-only skip |

**Best condition in the latest saved run: S800.** It reaches **13/24** Hit@5-all, **14/24** complete answers, and **50/50** supported citations. It is not a solved condition: 11 answerable questions still lack complete evidence coverage, and 20 answerable questions were incorrectly refused across the four conditions.

## Results

Latest saved run: `eval-ca61c0c0f4bc40339a321e93d80d0e45`.

| Condition | Chunks | Hit@5-any | Hit@5-all | Complete/24 | Partial | Wrong | Mis-refusal | Citation support |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| F400 | 982 | 9/24 | 4/24 | 6 | 10 | 8 | 5 | 28/35 |
| S400 | 1,415 | 14/24 | 6/24 | 9 | 9 | 6 | 6 | 33/35 |
| F800 | 493 | 17/24 | 10/24 | 10 | 7 | 7 | 6 | 43/46 |
| **S800** | **625** | **21/24** | **13/24** | **14** | **7** | **3** | **3** | **50/50** |

`Hit@k` is strict: the union of retrieved character intervals in the same document must fully cover the annotated evidence span. “Same article” is not enough.

Scoring is mixed-source: **21 items were human-confirmed and 99 were scored with authorized AI assistance**. This is not described as an all-human independent gold standard. All 24 should-refuse records were correctly refused, but that does not offset the 20 mis-refusals of answerable questions.

## Repository layout

```text
app/                 FastAPI app, QA pipeline, retrieval, evaluation, persistence
scripts/             corpus/index/evaluation CLIs, including build_p800/eval_p800
tests/               automated tests, including test_parent_child.py
config/              development + formal experiment configurations
data/                frozen EUR-Lex corpus, gold set, manifests, source registry
docs/                design notes, handoffs, worklogs, C report, P800 design
delivery/            offline delivery navigation
exports/             GitHub-friendly subset of the latest saved evaluation
presentation/        15-minute defense deck, PDF, speaker notes
README_ORIGINAL.md   full earlier README with stage history and detailed commands
```

Not uploaded here: the full `artifacts/` tree (~306 MB of stage logs, repeated test XML, intermediate restore snapshots), model weights, `.venv`, Chroma/SQLite runtime data, and the SQLite backup inside the export. See [artifacts/README.md](artifacts/README.md) and [exports/README.md](exports/README.md).

## Quick start

Requires **Python 3.13.11**. Commands are PowerShell from the repository root. See [GITHUB_UPLOAD.md](GITHUB_UPLOAD.md) for the Git commands.



```powershell
py -3.13 -m venv .venv
& '.\.venv\Scripts\python.exe' -m pip install -r requirements-dev.txt

# Optional: only needed for new LLM calls
Copy-Item .env.example .env
# Fill LLM_API_KEY in .env; never commit .env
```

The formal configuration is `config/experiment.formal-a.json`. The default `config/experiment.json` is a development sample.

### Build the four indexes and run the app

```powershell
# First model download: about 2.3 GB, CPU BGE-M3
& '.\.venv\Scripts\python.exe' -m scripts.fetch_embedding `
  --config config/experiment.formal-a.json

# Build F400/S400/F800/S800; first CPU build is about 26 minutes
& '.\.venv\Scripts\python.exe' -m scripts.build_indexes `
  --config config/experiment.formal-a.json

& '.\.venv\Scripts\python.exe' -m uvicorn app.main:app `
  --host 127.0.0.1 --port 8765
```

Open `http://127.0.0.1:8765`. The four pages are Chat, Documents, Chunk compare, and Evaluation.

### Run tests

```powershell
# Focused retrieval/chunking/extension tests, no model download
& '.\.venv\Scripts\python.exe' -m pytest `
  tests/test_chunking.py tests/test_retrieval.py tests/test_parent_child.py -q

# Full suite
& '.\.venv\Scripts\python.exe' -m pytest -q
```

## Chunking experiment

Two methods × two character limits:

- **Fixed window**: cut every 400 or 800 Python characters; may split a sentence, condition, or article.
- **Article structure**: use A's chapter/article offsets; pack complete articles until the limit; split overlong articles at sentence boundaries; hard-cut only if a single sentence still exceeds the limit.

All four groups use the same frozen text, pinned BGE-M3 (`5617a9f61b028005a4858fdac845db406aefb181`, 1024-d), Chroma cosine/HNSW, Top-5 retrieval, no overlap, and the same 30 questions. 400/800 are **characters**, not tokens.

## P800 parent–child extension

Member D's extension targets a specific failure mode: in the S800 run, 7 of 24 answerable questions have all evidence inside some S800 parent, but the correct parent is not in the Top-5. P800 keeps the S800 parent as the evidence unit and uses **250-character sentence-aligned children** only for matching:

```text
parent = S800 chunk (≤800 chars)
child  = 250-char sentence-aligned slice
index  = child vectors only
query  = Top-50 children → group by parent → parent score = max(child score) → Top-5 parents
LLM    = still reads the five full parents
```

On the frozen corpus this yields **625 parents, 2,343 child spans, 2,099 indexed children**, with 620/625 parents reachable. The code, build script, retrieval-only evaluator, and 9 unit tests are included. **The real BGE-M3/Chroma P800 run was not completed when this repository was packaged**, so no P800 performance claim is made. See [docs/父子分块扩展.md](docs/父子分块扩展.md).

```powershell
& '.\.venv\Scripts\python.exe' -m scripts.build_p800 `
  --config config/experiment.formal-a.json --dry-run

& '.\.venv\Scripts\python.exe' -m scripts.build_p800 `
  --config config/experiment.formal-a.json

& '.\.venv\Scripts\python.exe' -m scripts.eval_p800 `
  --config config/experiment.formal-a.json `
  --baseline exports/20261120-232137-eval-ca61c0c0/evaluation.json
```

## Data and versions

- `corpus_version`: `794e3d1956fc324659da149d5bfb0e083d257845895057b631d4578ec5b29795`
- `gold_version`: `9ecc1d148c00dacc354a401bdeae7dc019de871919d9ad673a53a9e491e9f07d`
- Sources: EUR-Lex original Official Journal versions, not later consolidated amendments.
- Directives: 2011/83/EU (35 articles), 2019/770 (27), 2019/771 (27), 2005/29/EC (21), 93/13/EEC (11).

The raw snapshots, cleaned text, article intervals, manifests, source URLs, and SHA-256 records are in `data/`. EUR-Lex texts remain subject to their original terms; this repository is for coursework and research use.

## Presentation

- [presentation/DERag_Group4_15min.pptx](presentation/DERag_Group4_15min.pptx) — 20 slides, editable, with speaker notes
- [presentation/DERag_Group4_15min.pdf](presentation/DERag_Group4_15min.pdf) — PDF backup
- [presentation/DERag_Group4_speaker_notes.md](presentation/DERag_Group4_speaker_notes.md) — printable 15-minute script
- [presentation/README.md](presentation/README.md) — timing and structure

Timing: A 0:00–3:25, B 3:25–6:25, C 6:25–9:20, D 9:20–12:00, conclusion 12:00–12:45, Q&A 12:45–15:00.

## Team contributions

| Member | Contribution |
|---|---|
| A | Official source collection, frozen corpus, article structure, 30-question gold set and evidence spans |
| B | Fixed/structure chunking, BGE-M3 embeddings, four Chroma indexes, Top-5 retrieval and version checks |
| C | LLM client, citation-constrained answers, backend validation, persistence, evaluation/scoring/export, four-page integration |
| D | P800 parent–child retrieval extension, diagnostic of ranking-gap cases, retrieval-only evaluation harness, presentation |

## Detailed documentation

- [项目设计.md](项目设计.md) — project design, research question, data model, evaluation metrics
- [工作文档.md](工作文档.md) — B's 696-line walkthrough: numbers, failure cases, defense Q&A
- [docs/C部分报告草稿.md](docs/C部分报告草稿.md) — C's experiment/implementation report
- [docs/父子分块扩展.md](docs/父子分块扩展.md) — P800 method, metrics, commands, limitations
- [docs/评估使用说明.md](docs/评估使用说明.md) — evaluation UI and scoring workflow
- [README_ORIGINAL.md](README_ORIGINAL.md) — full stage history, earlier network/key setup, delivery notes

## Known limitations

- One frozen 30-question run; this is not a statistical proof or a claim of general legal superiority.
- S800 is best in this run, but 11/24 answerable questions still lack complete evidence coverage and 20 answerable questions were incorrectly refused.
- Context budgets are not exactly equal across conditions; this is a comparison of four practical configurations, not an equal-token causal experiment.
- Scoring is mixed-source (21 human-confirmed + 99 authorized AI-assisted), not an all-human independent gold standard.
- The P800 real retrieval run is the next experiment; the current repository reports its diagnostic and implementation status, not a performance win.
